"use client"

import type React from "react"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { createClient } from "@supabase/supabase-js"
import { Menu, X, GraduationCap, BookOpen, Video, LogOut, User, Settings } from "lucide-react"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

interface NavLink {
  href: string
  label: string
  icon: React.ReactNode
  roles?: string[]
}

const navLinks: NavLink[] = [
  {
    href: "/student/study-library",
    label: "Study Library",
    icon: <BookOpen className="h-4 w-4" />,
    roles: ["student"],
  },
  {
    href: "/instructor",
    label: "Dashboard",
    icon: <Settings className="h-4 w-4" />,
    roles: ["instructor"],
  },
  {
    href: "/instructor/videos",
    label: "Manage Videos",
    icon: <Video className="h-4 w-4" />,
    roles: ["instructor"],
  },
  {
    href: "/instructor/create-quiz",
    label: "Create Quiz",
    icon: <GraduationCap className="h-4 w-4" />,
    roles: ["instructor"],
  },
]

export default function NavBar() {
  const pathname = usePathname()
  const router = useRouter()
  const [isOpen, setIsOpen] = useState(false)
  const [user, setUser] = useState<any>(null)
  const [userRole, setUserRole] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const getUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      setUser(user)

      if (user) {
        const { data: profile } = await supabase.from("user_profiles").select("role").eq("id", user.id).single()

        setUserRole(profile?.role || null)
      }
      setLoading(false)
    }

    getUser()

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      setUser(session?.user || null)
      if (session?.user) {
        const { data: profile } = await supabase.from("user_profiles").select("role").eq("id", session.user.id).single()

        setUserRole(profile?.role || null)
      } else {
        setUserRole(null)
      }
    })

    return () => subscription.unsubscribe()
  }, [])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  const filteredLinks = navLinks.filter((link) => {
    if (!link.roles) return true
    if (!userRole) return false
    return link.roles.includes(userRole)
  })

  if (loading) {
    return (
      <nav className="bg-gradient-to-r from-blue-950 to-slate-950 text-white shadow-xl border-b border-yellow-400/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="text-xl font-bold text-yellow-400">📘 E-Deck ConstructIQ</div>
            </div>
          </div>
        </div>
      </nav>
    )
  }

  return (
    <nav className="bg-gradient-to-r from-blue-950 to-slate-950 text-white shadow-xl border-b border-yellow-400/20 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3 hover:opacity-80 transition-opacity">
            <div className="text-xl font-bold text-yellow-400">📘 E-Deck ConstructIQ</div>
            <div className="hidden sm:block text-xs text-slate-300 italic">by S F Johnson Enterprises, LLC</div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {filteredLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  pathname === link.href
                    ? "bg-yellow-400/20 text-yellow-400 shadow-lg"
                    : "text-slate-300 hover:text-yellow-400 hover:bg-white/5"
                }`}
              >
                {link.icon}
                <span>{link.label}</span>
              </Link>
            ))}
          </div>

          {/* User Menu */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2 text-sm">
                  <User className="h-4 w-4 text-yellow-400" />
                  <span className="text-slate-300">{user.email}</span>
                  {userRole && (
                    <span className="bg-yellow-400/20 text-yellow-400 px-2 py-1 rounded-full text-xs font-medium">
                      {userRole}
                    </span>
                  )}
                </div>
                <Button
                  onClick={handleSignOut}
                  variant="ghost"
                  size="sm"
                  className="text-slate-300 hover:text-red-400 hover:bg-red-400/10"
                >
                  <LogOut className="h-4 w-4 mr-1" />
                  Sign Out
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Link href="/student">
                  <Button variant="ghost" size="sm" className="text-slate-300 hover:text-yellow-400">
                    Student Login
                  </Button>
                </Link>
                <Link href="/admin/login">
                  <Button variant="primary" size="sm">
                    Instructor Login
                  </Button>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button variant="ghost" size="sm" onClick={() => setIsOpen(!isOpen)} className="text-yellow-400">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden border-t border-slate-700 bg-slate-900/50 backdrop-blur-sm">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {filteredLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className={`flex items-center space-x-3 px-3 py-2 rounded-lg text-base font-medium transition-all ${
                    pathname === link.href
                      ? "bg-yellow-400/20 text-yellow-400"
                      : "text-slate-300 hover:text-yellow-400 hover:bg-white/5"
                  }`}
                >
                  {link.icon}
                  <span>{link.label}</span>
                </Link>
              ))}

              {/* Mobile User Section */}
              <div className="border-t border-slate-700 pt-3 mt-3">
                {user ? (
                  <div className="space-y-2">
                    <div className="px-3 py-2 text-sm text-slate-300">
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4 text-yellow-400" />
                        <span>{user.email}</span>
                      </div>
                      {userRole && (
                        <div className="mt-1">
                          <span className="bg-yellow-400/20 text-yellow-400 px-2 py-1 rounded-full text-xs font-medium">
                            {userRole}
                          </span>
                        </div>
                      )}
                    </div>
                    <Button
                      onClick={handleSignOut}
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start text-slate-300 hover:text-red-400 hover:bg-red-400/10"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign Out
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Link href="/student" onClick={() => setIsOpen(false)}>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="w-full justify-start text-slate-300 hover:text-yellow-400"
                      >
                        Student Login
                      </Button>
                    </Link>
                    <Link href="/admin/login" onClick={() => setIsOpen(false)}>
                      <Button variant="primary" size="sm" className="w-full">
                        Instructor Login
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
