"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Shield, Lock, Mail, ArrowRight, AlertCircle } from "lucide-react"
import { loginAdmin, loginInstructor } from "@/lib/auth"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"

export default function AdminLogin() {
  const [email, setEmail] = useState("info@sfjohnsonconsulting.com")
  const [password, setPassword] = useState("e-deck07")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [loginType, setLoginType] = useState<"admin" | "instructor">("instructor")
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const result =
        loginType === "admin" ? await loginAdmin({ email, password }) : await loginInstructor({ email, password })

      if (result.success) {
        toast({
          title: "Login Successful",
          description: `Welcome back, ${result.role}!`,
        })

        if (result.role === "admin") {
          router.push("/admin/dashboard")
        } else {
          router.push("/instructor")
        }
      } else {
        setError(result.error || "Login failed")
      }
    } catch (err) {
      setError("An unexpected error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="p-3 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-lg shadow-lg">
              <Shield className="h-8 w-8 text-black" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-yellow-400">E-Deck ConstructIQ</h1>
              <p className="text-sm text-slate-300">Admin Portal</p>
            </div>
          </div>
        </div>

        <Card className="shadow-2xl border-slate-700 bg-slate-800/50 backdrop-blur-sm">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl font-bold text-white">
              {loginType === "admin" ? "Administrator" : "Instructor"} Login
            </CardTitle>
            <CardDescription className="text-slate-300">
              Access the {loginType === "admin" ? "admin dashboard" : "instructor portal"}
            </CardDescription>
          </CardHeader>

          <CardContent>
            {/* Login Type Toggle */}
            <div className="flex mb-6 bg-slate-700 rounded-lg p-1">
              <button
                type="button"
                onClick={() => setLoginType("instructor")}
                className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all ${
                  loginType === "instructor" ? "bg-yellow-400 text-black shadow-md" : "text-slate-300 hover:text-white"
                }`}
              >
                Instructor
              </button>
              <button
                type="button"
                onClick={() => setLoginType("admin")}
                className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all ${
                  loginType === "admin" ? "bg-yellow-400 text-black shadow-md" : "text-slate-300 hover:text-white"
                }`}
              >
                Administrator
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-200">
                  Email Address
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="pl-10 h-12 bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 focus:border-yellow-400"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-200">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="pl-10 h-12 bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 focus:border-yellow-400"
                    required
                  />
                </div>
              </div>

              {error && (
                <Alert className="border-red-500 bg-red-500/10">
                  <AlertCircle className="h-4 w-4 text-red-400" />
                  <AlertDescription className="text-red-300">{error}</AlertDescription>
                </Alert>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="w-full h-12 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-300 hover:to-yellow-400 text-black font-bold text-lg shadow-lg hover:shadow-xl transition-all duration-300"
              >
                {loading ? (
                  "Signing in..."
                ) : (
                  <>
                    Sign In as {loginType === "admin" ? "Admin" : "Instructor"}
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-slate-400 text-sm mb-2">
                {loginType === "admin" ? "Need instructor access?" : "Need admin access?"}
              </p>
              <button
                onClick={() => setLoginType(loginType === "admin" ? "instructor" : "admin")}
                className="text-yellow-400 hover:text-yellow-300 text-sm font-medium"
              >
                Switch to {loginType === "admin" ? "Instructor" : "Admin"} Login
              </button>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 text-center">
          <Link href="/" className="text-sm text-slate-400 hover:text-yellow-400 transition-colors">
            ← Back to Home
          </Link>
        </div>

        <div className="mt-4 text-center">
          <p className="text-xs text-slate-400">© 2025 S F Johnson Enterprises, LLC</p>
        </div>
      </div>
    </div>
  )
}
