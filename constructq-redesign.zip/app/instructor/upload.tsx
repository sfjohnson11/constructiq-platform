// File: app/instructor/upload.tsx
"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Upload, FileText, AlertCircle, CheckCircle } from "lucide-react"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

interface Project {
  id: string
  name: string
}

export default function UploadPlansPage() {
  const [existingProjects, setExistingProjects] = useState<Project[]>([])
  const [useExistingProject, setUseExistingProject] = useState(false)
  const [selectedProjectId, setSelectedProjectId] = useState("")
  const [projectName, setProjectName] = useState("")
  const [projectDescription, setProjectDescription] = useState("")
  const [planLabel, setPlanLabel] = useState("")
  const [file, setFile] = useState<File | null>(null)
  const [status, setStatus] = useState("")
  const [uploading, setUploading] = useState(false)

  useEffect(() => {
    const fetchProjects = async () => {
      const { data } = await supabase.from("electrical_projects").select("id, name").order("name")
      if (data) setExistingProjects(data)
    }
    fetchProjects()
  }, [])

  const resetForm = () => {
    setProjectName("")
    setProjectDescription("")
    setPlanLabel("")
    setFile(null)
    setSelectedProjectId("")
    setStatus("")
  }

  const validateForm = () => {
    if (useExistingProject && !selectedProjectId) {
      setStatus("❌ Please select an existing project.")
      return false
    }
    if (!useExistingProject && !projectName.trim()) {
      setStatus("❌ Please enter a project name.")
      return false
    }
    if (!planLabel.trim()) {
      setStatus("❌ Please enter a plan set label.")
      return false
    }
    if (!file) {
      setStatus("❌ Please select a file to upload.")
      return false
    }
    return true
  }

  const handleUpload = async () => {
    if (!validateForm()) return

    setUploading(true)
    setStatus("📤 Uploading...")

    try {
      let projectId = selectedProjectId

      // Create new project if not using existing
      if (!useExistingProject) {
        const { data: project, error: projectError } = await supabase
          .from("electrical_projects")
          .insert([
            {
              name: projectName.trim(),
              description: projectDescription.trim(),
            },
          ])
          .select()
          .single()

        if (projectError || !project) {
          setStatus("❌ Failed to create project.")
          setUploading(false)
          return
        }
        projectId = project.id
      }

      // Upload file to Supabase Storage
      const fileExtension = file!.name.split(".").pop()
      const fileName = `${Date.now()}-${planLabel.replace(/[^a-zA-Z0-9]/g, "_")}.${fileExtension}`
      const filePath = `plans/${fileName}`

      const { error: uploadError } = await supabase.storage.from("electrical").upload(filePath, file!)

      if (uploadError) {
        setStatus("❌ Failed to upload file to storage.")
        setUploading(false)
        return
      }

      // Get public URL
      const {
        data: { publicUrl },
      } = supabase.storage.from("electrical").getPublicUrl(filePath)

      // Insert plan set record
      const { error: planError } = await supabase.from("electrical_plan_sets").insert([
        {
          project_id: projectId,
          title: planLabel.trim(),
          file_url: publicUrl,
        },
      ])

      if (planError) {
        setStatus("❌ Failed to save plan metadata.")
      } else {
        setStatus("✅ Upload successful!")
        resetForm()
      }
    } catch (error) {
      setStatus("❌ An unexpected error occurred.")
      console.error(error)
    }

    setUploading(false)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-950 to-blue-950 text-white py-12 px-6">
      <div className="max-w-4xl mx-auto space-y-8">
        <header className="text-center">
          <div className="flex items-center justify-center mb-4">
            <FileText className="h-10 w-10 text-yellow-400 mr-3" />
            <h1 className="text-4xl font-bold text-yellow-400">Upload Electrical Plans</h1>
          </div>
          <p className="text-blue-200 italic">E-Deck ConstructIQ by S F Johnson Enterprises, LLC</p>
        </header>

        <div className="bg-slate-800 bg-opacity-50 rounded-2xl p-8 border border-slate-600 space-y-6">
          {/* Project Selection */}
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <input
                type="radio"
                id="newProject"
                name="projectType"
                checked={!useExistingProject}
                onChange={() => setUseExistingProject(false)}
                className="text-yellow-400"
              />
              <Label htmlFor="newProject" className="text-blue-200">
                Create New Project
              </Label>
              <input
                type="radio"
                id="existingProject"
                name="projectType"
                checked={useExistingProject}
                onChange={() => setUseExistingProject(true)}
                className="text-yellow-400"
              />
              <Label htmlFor="existingProject" className="text-blue-200">
                Add to Existing Project
              </Label>
            </div>

            {useExistingProject ? (
              <div>
                <Label htmlFor="existingProjectSelect" className="text-blue-200 mb-2 block">
                  Select Existing Project *
                </Label>
                <select
                  id="existingProjectSelect"
                  value={selectedProjectId}
                  onChange={(e) => setSelectedProjectId(e.target.value)}
                  className="w-full bg-slate-700 text-white p-3 rounded-xl border border-slate-600 focus:border-yellow-400 focus:outline-none"
                >
                  <option value="">-- Select a Project --</option>
                  {existingProjects.map((project) => (
                    <option key={project.id} value={project.id}>
                      {project.name}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="projectName" className="text-blue-200 mb-2 block">
                    Project Name *
                  </Label>
                  <Input
                    id="projectName"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    placeholder="Enter project name"
                    className="bg-slate-700 border-slate-600 text-white focus:border-yellow-400"
                  />
                </div>
                <div>
                  <Label htmlFor="projectDescription" className="text-blue-200 mb-2 block">
                    Project Description
                  </Label>
                  <Input
                    id="projectDescription"
                    value={projectDescription}
                    onChange={(e) => setProjectDescription(e.target.value)}
                    placeholder="Enter project description (optional)"
                    className="bg-slate-700 border-slate-600 text-white focus:border-yellow-400"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Plan Set Details */}
          <div>
            <Label htmlFor="planLabel" className="text-blue-200 mb-2 block">
              Plan Set Label *
            </Label>
            <Input
              id="planLabel"
              value={planLabel}
              onChange={(e) => setPlanLabel(e.target.value)}
              placeholder="e.g., Electrical Floor Plan - Level 1"
              className="bg-slate-700 border-slate-600 text-white focus:border-yellow-400"
            />
          </div>

          {/* File Upload */}
          <div>
            <Label htmlFor="fileUpload" className="text-blue-200 mb-2 block">
              Upload File *
            </Label>
            <input
              id="fileUpload"
              type="file"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
              accept=".pdf,.jpg,.jpeg,.png,.mp4,.mov"
              className="w-full file:bg-yellow-400 file:text-black file:font-semibold file:px-4 file:py-2 file:rounded-xl file:border-none file:mr-4 bg-slate-700 text-white rounded-xl border border-slate-600 p-3"
            />
            <p className="text-slate-400 text-sm mt-2">Supported formats: PDF, Images (JPG, PNG), Videos (MP4, MOV)</p>
          </div>

          {/* Upload Button */}
          <div className="flex justify-center pt-4">
            <Button
              onClick={handleUpload}
              disabled={uploading}
              className="bg-yellow-400 text-black px-8 py-3 rounded-xl hover:bg-yellow-300 transition-all duration-300 flex items-center gap-2 font-bold text-lg disabled:opacity-50"
            >
              <Upload className="h-5 w-5" />
              {uploading ? "Uploading..." : "Upload Plan"}
            </Button>
          </div>

          {/* Status Message */}
          {status && (
            <div className="flex items-center justify-center gap-2 mt-4">
              {status.includes("✅") ? (
                <CheckCircle className="h-5 w-5 text-green-400" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-400" />
              )}
              <p className="font-semibold">{status}</p>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
