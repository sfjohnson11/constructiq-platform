// File: app/instructor/videos/page.tsx
"use client"

import { useEffect, useState } from "react"
import { createClient } from "@supabase/supabase-js"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Video, Plus, Eye } from "lucide-react"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

type Project = {
  id: string
  name: string
  description: string
  created_at: string
}

type PlanSet = {
  id: string
  title: string
  project_id: string
  file_url: string
  uploaded_at: string
}

export default function InstructorVideosPage() {
  const [projects, setProjects] = useState<Project[]>([])
  const [planSets, setPlanSets] = useState<{ [key: string]: PlanSet[] }>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      setLoading(true)

      // Load projects
      const { data: projectData, error: projectError } = await supabase
        .from("electrical_projects")
        .select("id, name, description, created_at")
        .order("created_at", { ascending: false })

      if (!projectError && projectData) {
        setProjects(projectData)

        // Load plan sets for each project
        const { data: planSetData, error: planSetError } = await supabase
          .from("electrical_plan_sets")
          .select("id, title, project_id, file_url, uploaded_at")
          .order("uploaded_at", { ascending: false })

        if (!planSetError && planSetData) {
          // Group plan sets by project
          const groupedPlanSets = planSetData.reduce(
            (acc, planSet) => {
              if (!acc[planSet.project_id]) {
                acc[planSet.project_id] = []
              }
              acc[planSet.project_id].push(planSet)
              return acc
            },
            {} as { [key: string]: PlanSet[] },
          )

          setPlanSets(groupedPlanSets)
        }
      } else {
        console.error("Error loading projects:", projectError)
      }

      setLoading(false)
    }

    loadData()
  }, [])

  if (loading) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-blue-950 to-slate-950 text-white py-12 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-blue-200">Loading projects and videos...</p>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-950 to-slate-950 text-white py-12 px-6">
      <div className="max-w-6xl mx-auto space-y-8">
        <header className="text-center">
          <h1 className="text-4xl font-extrabold text-yellow-400">🎥 Project Videos</h1>
          <p className="text-blue-200 italic">E-Deck ConstructIQ by S F Johnson Enterprises, LLC</p>
        </header>

        <div className="flex justify-end">
          <Link href="/instructor/upload">
            <Button className="bg-yellow-400 text-black hover:bg-yellow-300 flex items-center gap-2">
              <Plus size={18} />
              Upload New Video
            </Button>
          </Link>
        </div>

        <div className="space-y-8">
          {projects.length === 0 ? (
            <div className="text-center py-12">
              <Video className="h-16 w-16 text-slate-400 mx-auto mb-4" />
              <p className="text-slate-400 text-lg">No projects found</p>
              <p className="text-slate-500 text-sm">Create your first project to get started</p>
            </div>
          ) : (
            projects.map((project) => (
              <div
                key={project.id}
                className="bg-blue-800 bg-opacity-30 border border-yellow-500 rounded-xl p-6 shadow-md"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h2 className="text-2xl font-bold text-yellow-300">{project.name}</h2>
                    <p className="text-blue-200 text-sm">{project.description}</p>
                    <p className="text-slate-400 text-xs mt-1">
                      Created: {new Date(project.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <Link href={`/projects/${project.id}`}>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black bg-transparent"
                    >
                      <Eye size={16} className="mr-1" />
                      View Project
                    </Button>
                  </Link>
                </div>

                <div className="space-y-3">
                  <h3 className="text-lg font-semibold text-blue-200">Plan Sets & Videos:</h3>
                  {planSets[project.id] && planSets[project.id].length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {planSets[project.id].map((planSet) => (
                        <div
                          key={planSet.id}
                          className="bg-slate-800 bg-opacity-50 border border-slate-600 rounded-lg p-4"
                        >
                          <h4 className="text-yellow-200 font-medium">{planSet.title}</h4>
                          <p className="text-slate-400 text-xs mb-2">
                            Uploaded: {new Date(planSet.uploaded_at).toLocaleDateString()}
                          </p>
                          <div className="flex gap-2">
                            <a
                              href={planSet.file_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-400 hover:text-blue-300 text-sm underline"
                            >
                              View File
                            </a>
                            <Link
                              href={`/projects/${project.id}/plan-set/${planSet.id}/manage`}
                              className="text-green-400 hover:text-green-300 text-sm underline"
                            >
                              Manage
                            </Link>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-400 italic text-sm">No plan sets uploaded yet</p>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </main>
  )
}
