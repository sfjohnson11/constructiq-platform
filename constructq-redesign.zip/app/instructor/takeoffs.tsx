"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { createClient } from "@supabase/supabase-js"
import { Calculator, Save, AlertCircle } from "lucide-react"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

interface Project {
  id: string
  name: string
}

interface PlanSet {
  id: string
  title: string
  project_id: string
}

export default function TakeoffCreator() {
  const [projects, setProjects] = useState<Project[]>([])
  const [planSets, setPlanSets] = useState<PlanSet[]>([])
  const [selectedProject, setSelectedProject] = useState("")
  const [selectedPlanSet, setSelectedPlanSet] = useState("")
  const [itemLabel, setItemLabel] = useState("")
  const [description, setDescription] = useState("")
  const [location, setLocation] = useState("")
  const [unit, setUnit] = useState("")
  const [quantity, setQuantity] = useState("")
  const [laborHours, setLaborHours] = useState("")
  const [materialCost, setMaterialCost] = useState("")
  const [message, setMessage] = useState("")
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const fetchProjects = async () => {
      const { data } = await supabase.from("electrical_projects").select("id, name").order("name")

      if (data) setProjects(data)
    }

    fetchProjects()
  }, [])

  useEffect(() => {
    const fetchPlanSets = async () => {
      if (!selectedProject) {
        setPlanSets([])
        return
      }

      const { data } = await supabase
        .from("electrical_plan_sets")
        .select("id, title, project_id")
        .eq("project_id", selectedProject)
        .order("title")

      if (data) setPlanSets(data)
    }

    fetchPlanSets()
  }, [selectedProject])

  const resetForm = () => {
    setItemLabel("")
    setDescription("")
    setLocation("")
    setUnit("")
    setQuantity("")
    setLaborHours("")
    setMaterialCost("")
  }

  const validateForm = () => {
    if (
      !selectedProject ||
      !selectedPlanSet ||
      !itemLabel ||
      !description ||
      !unit ||
      !quantity ||
      !laborHours ||
      !materialCost
    ) {
      setMessage("❌ Please fill out all required fields.")
      return false
    }

    if (Number.parseFloat(quantity) <= 0 || Number.parseFloat(laborHours) < 0 || Number.parseFloat(materialCost) < 0) {
      setMessage("❌ Please enter valid numeric values.")
      return false
    }

    return true
  }

  const handleSubmit = async () => {
    if (!validateForm()) return

    setLoading(true)
    setMessage("")

    const { error } = await supabase.from("electrical_takeoff_items").insert([
      {
        project_id: selectedProject,
        plan_set_id: selectedPlanSet,
        item_label: itemLabel,
        description,
        location,
        unit,
        quantity: Number.parseFloat(quantity),
        labor_hours: Number.parseFloat(laborHours),
        material_cost: Number.parseFloat(materialCost),
      },
    ])

    setLoading(false)

    if (error) {
      setMessage("❌ Error saving takeoff item.")
      console.error(error)
    } else {
      setMessage("✅ Takeoff item saved successfully.")
      resetForm()
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-950 to-blue-950 text-white py-12 px-6">
      <div className="max-w-4xl mx-auto space-y-8">
        <header className="text-center">
          <div className="flex items-center justify-center mb-4">
            <Calculator className="h-10 w-10 text-yellow-400 mr-3" />
            <h1 className="text-4xl font-bold text-yellow-400">Create Electrical Takeoff Item</h1>
          </div>
          <p className="text-blue-200 italic">E-Deck ConstructIQ by S F Johnson Enterprises, LLC</p>
        </header>

        <div className="bg-slate-800 bg-opacity-50 rounded-2xl p-8 border border-slate-600 space-y-6">
          {/* Project Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="project" className="text-blue-200 mb-2 block">
                Project *
              </Label>
              <select
                id="project"
                className="w-full bg-slate-700 text-white p-3 rounded-xl border border-slate-600 focus:border-yellow-400 focus:outline-none"
                value={selectedProject}
                onChange={(e) => setSelectedProject(e.target.value)}
              >
                <option value="">-- Select a Project --</option>
                {projects.map((proj) => (
                  <option key={proj.id} value={proj.id}>
                    {proj.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <Label htmlFor="planSet" className="text-blue-200 mb-2 block">
                Plan Set *
              </Label>
              <select
                id="planSet"
                className="w-full bg-slate-700 text-white p-3 rounded-xl border border-slate-600 focus:border-yellow-400 focus:outline-none"
                value={selectedPlanSet}
                onChange={(e) => setSelectedPlanSet(e.target.value)}
                disabled={!selectedProject}
              >
                <option value="">-- Select Plan Set --</option>
                {planSets.map((ps) => (
                  <option key={ps.id} value={ps.id}>
                    {ps.title}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Item Details */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="itemLabel" className="text-blue-200 mb-2 block">
                  Item Label *
                </Label>
                <Input
                  id="itemLabel"
                  value={itemLabel}
                  onChange={(e) => setItemLabel(e.target.value)}
                  placeholder="e.g., Branch Circuit A1"
                  className="bg-slate-700 border-slate-600 text-white focus:border-yellow-400"
                />
              </div>

              <div>
                <Label htmlFor="unit" className="text-blue-200 mb-2 block">
                  Unit *
                </Label>
                <Input
                  id="unit"
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  placeholder="e.g., EA, LF, FT"
                  className="bg-slate-700 border-slate-600 text-white focus:border-yellow-400"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description" className="text-blue-200 mb-2 block">
                Description *
              </Label>
              <Input
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Full scope description"
                className="bg-slate-700 border-slate-600 text-white focus:border-yellow-400"
              />
            </div>

            <div>
              <Label htmlFor="location" className="text-blue-200 mb-2 block">
                Location
              </Label>
              <Input
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Optional area or room"
                className="bg-slate-700 border-slate-600 text-white focus:border-yellow-400"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="quantity" className="text-blue-200 mb-2 block">
                  Quantity *
                </Label>
                <Input
                  id="quantity"
                  type="number"
                  step="0.01"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  placeholder="Enter quantity"
                  className="bg-slate-700 border-slate-600 text-white focus:border-yellow-400"
                />
              </div>

              <div>
                <Label htmlFor="laborHours" className="text-blue-200 mb-2 block">
                  Labor Hours *
                </Label>
                <Input
                  id="laborHours"
                  type="number"
                  step="0.01"
                  value={laborHours}
                  onChange={(e) => setLaborHours(e.target.value)}
                  placeholder="Enter labor hours"
                  className="bg-slate-700 border-slate-600 text-white focus:border-yellow-400"
                />
              </div>

              <div>
                <Label htmlFor="materialCost" className="text-blue-200 mb-2 block">
                  Material Cost *
                </Label>
                <Input
                  id="materialCost"
                  type="number"
                  step="0.01"
                  value={materialCost}
                  onChange={(e) => setMaterialCost(e.target.value)}
                  placeholder="Enter cost"
                  className="bg-slate-700 border-slate-600 text-white focus:border-yellow-400"
                />
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-center pt-4">
            <Button
              onClick={handleSubmit}
              disabled={loading}
              className="bg-yellow-400 text-black px-8 py-3 rounded-xl hover:bg-yellow-300 transition-all duration-300 flex items-center gap-2 font-bold text-lg"
            >
              <Save className="h-5 w-5" />
              {loading ? "Saving..." : "Save Takeoff Item"}
            </Button>
          </div>

          {/* Message */}
          {message && (
            <div className="flex items-center justify-center gap-2 mt-4">
              <AlertCircle className="h-5 w-5" />
              <p className="font-semibold">{message}</p>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
