// File: app/instructor/page.tsx
"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Upload, FileText, BarChart3, Video, Users, BookOpen, PlusCircle } from "lucide-react"

export default function InstructorDashboardPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-950 to-slate-950 text-white py-12 px-6">
      <div className="max-w-7xl mx-auto space-y-12">
        <header className="text-center">
          <h1 className="text-4xl font-extrabold text-yellow-400">Instructor Dashboard</h1>
          <p className="text-blue-200 italic">E-Deck ConstructIQ by S F Johnson Enterprises, LLC</p>
        </header>

        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Upload Plans */}
          <div className="bg-blue-800 bg-opacity-30 border border-yellow-500 rounded-2xl p-6 shadow-md hover:shadow-yellow-400 transition group">
            <div className="flex items-center mb-3">
              <Upload className="h-6 w-6 text-yellow-300 mr-2 group-hover:scale-110 transition-transform" />
              <h2 className="text-xl font-semibold text-yellow-300">Upload Plans</h2>
            </div>
            <p className="text-blue-200 mb-4">Start a new project by uploading plan sets for review and takeoff.</p>
            <Link href="/instructor/upload">
              <Button className="bg-yellow-400 text-black hover:bg-yellow-300 w-full font-bold">Upload Now</Button>
            </Link>
          </div>

          {/* Manage Projects */}
          <div className="bg-blue-800 bg-opacity-30 border border-yellow-500 rounded-2xl p-6 shadow-md hover:shadow-yellow-400 transition group">
            <div className="flex items-center mb-3">
              <BookOpen className="h-6 w-6 text-yellow-300 mr-2 group-hover:scale-110 transition-transform" />
              <h2 className="text-xl font-semibold text-yellow-300">Manage Projects</h2>
            </div>
            <p className="text-blue-200 mb-4">View and manage all your electrical projects and plan sets.</p>
            <Link href="/projects">
              <Button className="bg-yellow-400 text-black hover:bg-yellow-300 w-full font-bold">View Projects</Button>
            </Link>
          </div>

          {/* Create Quizzes */}
          <div className="bg-blue-800 bg-opacity-30 border border-yellow-500 rounded-2xl p-6 shadow-md hover:shadow-yellow-400 transition group">
            <div className="flex items-center mb-3">
              <FileText className="h-6 w-6 text-yellow-300 mr-2 group-hover:scale-110 transition-transform" />
              <h2 className="text-xl font-semibold text-yellow-300">Create Quizzes</h2>
            </div>
            <p className="text-blue-200 mb-4">Design quizzes for each video lesson to test student knowledge.</p>
            <Link href="/instructor/create-quiz">
              <Button className="bg-yellow-400 text-black hover:bg-yellow-300 w-full font-bold">Create Quiz</Button>
            </Link>
          </div>

          {/* Manage Videos */}
          <div className="bg-blue-800 bg-opacity-30 border border-yellow-500 rounded-2xl p-6 shadow-md hover:shadow-yellow-400 transition group">
            <div className="flex items-center mb-3">
              <Video className="h-6 w-6 text-yellow-300 mr-2 group-hover:scale-110 transition-transform" />
              <h2 className="text-xl font-semibold text-yellow-300">Manage Videos</h2>
            </div>
            <p className="text-blue-200 mb-4">View and organize all your instructional videos and plan sets.</p>
            <Link href="/instructor/videos">
              <Button className="bg-yellow-400 text-black hover:bg-yellow-300 w-full font-bold">Manage Videos</Button>
            </Link>
          </div>

          {/* Review Student Work */}
          <div className="bg-blue-800 bg-opacity-30 border border-yellow-500 rounded-2xl p-6 shadow-md hover:shadow-yellow-400 transition group">
            <div className="flex items-center mb-3">
              <BarChart3 className="h-6 w-6 text-yellow-300 mr-2 group-hover:scale-110 transition-transform" />
              <h2 className="text-xl font-semibold text-yellow-300">Review Takeoffs</h2>
            </div>
            <p className="text-blue-200 mb-4">Compare student work to your own estimates and give feedback.</p>
            <Link href="/instructor/review">
              <Button className="bg-yellow-400 text-black hover:bg-yellow-300 w-full font-bold">Review Now</Button>
            </Link>
          </div>

          {/* Student Management */}
          <div className="bg-blue-800 bg-opacity-30 border border-yellow-500 rounded-2xl p-6 shadow-md hover:shadow-yellow-400 transition group">
            <div className="flex items-center mb-3">
              <Users className="h-6 w-6 text-yellow-300 mr-2 group-hover:scale-110 transition-transform" />
              <h2 className="text-xl font-semibold text-yellow-300">Student Progress</h2>
            </div>
            <p className="text-blue-200 mb-4">Monitor student progress, quiz scores, and completion rates.</p>
            <Link href="/instructor/students">
              <Button className="bg-yellow-400 text-black hover:bg-yellow-300 w-full font-bold">View Students</Button>
            </Link>
          </div>
        </section>

        {/* Quick Actions */}
        <section className="bg-slate-800 bg-opacity-50 rounded-2xl p-8 border border-slate-600">
          <h2 className="text-2xl font-bold text-yellow-300 mb-6 text-center">Quick Actions</h2>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/instructor/upload">
              <Button className="bg-green-600 hover:bg-green-500 text-white flex items-center gap-2">
                <PlusCircle size={18} />
                New Project
              </Button>
            </Link>
            <Link href="/instructor/create-quiz">
              <Button className="bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-2">
                <FileText size={18} />
                New Quiz
              </Button>
            </Link>
            <Link href="/projects">
              <Button className="bg-purple-600 hover:bg-purple-500 text-white flex items-center gap-2">
                <BookOpen size={18} />
                All Projects
              </Button>
            </Link>
            <Link href="/instructor/videos">
              <Button className="bg-orange-600 hover:bg-orange-500 text-white flex items-center gap-2">
                <Video size={18} />
                All Videos
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </main>
  )
}
