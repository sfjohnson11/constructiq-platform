"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@supabase/supabase-js"
import { Button } from "@/components/ui/button"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

export default function CreateQuizPage() {
  const router = useRouter()
  const [title, setTitle] = useState("")
  const [planSets, setPlanSets] = useState<{ id: string; name: string }[]>([])
  const [selectedPlanSet, setSelectedPlanSet] = useState("")
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState("")

  useEffect(() => {
    async function fetchPlanSets() {
      const { data } = await supabase
        .from("electrical_plan_sets")
        .select("id, title as name")
        .order("created_at", { ascending: false })

      setPlanSets(data || [])
    }

    fetchPlanSets()
  }, [])

  const handleCreateQuiz = async () => {
    if (!title || !selectedPlanSet) {
      setMessage("❌ Please fill in all fields")
      return
    }

    setSaving(true)
    setMessage("")

    const { data, error } = await supabase
      .from("electrical_quizzes")
      .insert([
        {
          title,
          plan_set_id: selectedPlanSet,
        },
      ])
      .select()
      .single()

    setSaving(false)

    if (error) {
      setMessage("❌ Quiz creation failed. Please try again.")
      console.error(error)
      return
    }

    setMessage("✅ Quiz created successfully!")
    setTimeout(() => {
      router.push(`/instructor/edit-quiz?quizId=${data.id}`)
    }, 1000)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-950 to-slate-950 text-white py-12 px-6">
      <div className="max-w-3xl mx-auto space-y-10">
        <header className="text-center">
          <h1 className="text-4xl font-bold text-yellow-400">🛠️ Create New Quiz</h1>
          <p className="text-blue-300 italic">E-Deck ConstructIQ by S F Johnson Enterprises, LLC</p>
        </header>

        <div className="space-y-6">
          <div>
            <label className="block text-blue-200 mb-2">Quiz Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-2 rounded-lg bg-blue-900 border border-blue-500 text-white"
              placeholder="Enter quiz title"
            />
          </div>

          <div>
            <label className="block text-blue-200 mb-2">Select Plan Set</label>
            <select
              value={selectedPlanSet}
              onChange={(e) => setSelectedPlanSet(e.target.value)}
              className="w-full px-4 py-2 rounded-lg bg-blue-900 border border-blue-500 text-white"
            >
              <option value="">-- Choose a plan set --</option>
              {planSets.map((set) => (
                <option key={set.id} value={set.id}>
                  {set.name}
                </option>
              ))}
            </select>
          </div>

          <Button
            onClick={handleCreateQuiz}
            disabled={saving || !title || !selectedPlanSet}
            className="bg-yellow-400 text-black text-lg px-6 py-3 rounded-xl hover:bg-yellow-300 transition disabled:opacity-50"
          >
            {saving ? "Creating..." : "Create Quiz"}
          </Button>

          {message && <p className="text-center font-semibold mt-4">{message}</p>}
        </div>
      </div>
    </main>
  )
}
