"use client"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, ArrowRight, GraduationCap, HardHat } from "lucide-react"
import Link from "next/link"

export default function LoginPage() {
  const [loginType, setLoginType] = useState<"student" | "instructor">("student")
  const router = useRouter()

  const handleRedirect = () => {
    if (loginType === "student") {
      router.push("/student")
    } else {
      router.push("/admin/login")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="p-3 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-lg shadow-lg">
              <Shield className="h-8 w-8 text-black" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-yellow-400">E-Deck ConstructIQ</h1>
              <p className="text-sm text-slate-300">Choose Your Portal</p>
            </div>
          </div>
        </div>

        <Card className="shadow-2xl border-slate-700 bg-slate-800/50 backdrop-blur-sm">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl font-bold text-white">Select Login Type</CardTitle>
            <CardDescription className="text-slate-300">
              Choose your role to access the appropriate portal
            </CardDescription>
          </CardHeader>

          <CardContent>
            {/* Login Type Selection */}
            <div className="space-y-4 mb-6">
              <button
                onClick={() => setLoginType("student")}
                className={`w-full p-4 rounded-xl border-2 transition-all duration-300 flex items-center gap-4 ${
                  loginType === "student"
                    ? "border-yellow-400 bg-yellow-400/10 text-yellow-400"
                    : "border-slate-600 bg-slate-700/50 text-slate-300 hover:border-slate-500"
                }`}
              >
                <GraduationCap className="h-6 w-6" />
                <div className="text-left">
                  <div className="font-semibold">Student Portal</div>
                  <div className="text-sm opacity-80">Access courses and training materials</div>
                </div>
              </button>

              <button
                onClick={() => setLoginType("instructor")}
                className={`w-full p-4 rounded-xl border-2 transition-all duration-300 flex items-center gap-4 ${
                  loginType === "instructor"
                    ? "border-yellow-400 bg-yellow-400/10 text-yellow-400"
                    : "border-slate-600 bg-slate-700/50 text-slate-300 hover:border-slate-500"
                }`}
              >
                <HardHat className="h-6 w-6" />
                <div className="text-left">
                  <div className="font-semibold">Instructor Portal</div>
                  <div className="text-sm opacity-80">Manage courses and student progress</div>
                </div>
              </button>
            </div>

            <Button
              onClick={handleRedirect}
              className="w-full h-12 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-300 hover:to-yellow-400 text-black font-bold text-lg shadow-lg hover:shadow-xl transition-all duration-300"
            >
              Continue to {loginType === "student" ? "Student" : "Instructor"} Login
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </CardContent>
        </Card>

        <div className="mt-6 text-center">
          <Link href="/" className="text-sm text-slate-400 hover:text-yellow-400 transition-colors">
            ← Back to Home
          </Link>
        </div>

        <div className="mt-4 text-center">
          <p className="text-xs text-slate-400">© 2025 S F Johnson Enterprises, LLC</p>
        </div>
      </div>
    </div>
  )
}
