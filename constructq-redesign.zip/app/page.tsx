"use client"

import { GraduationCap, HardHat, ExternalLink } from "lucide-react"

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-[#0a0a23] via-[#001F3F] to-[#0a0a23] text-white flex flex-col items-center justify-center px-6 py-16 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-32 h-32 bg-yellow-400/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-40 h-40 bg-yellow-400/10 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-yellow-400/15 rounded-full blur-2xl"></div>
      </div>

      <div className="text-center max-w-4xl w-full relative z-10">
        {/* Logo/Icon */}
        <div className="mb-8 flex justify-center">
          <div className="bg-yellow-400 p-4 rounded-2xl shadow-2xl">
            <HardHat className="h-12 w-12 text-[#0a0a23]" />
          </div>
        </div>

        <h1 className="text-5xl md:text-7xl font-black mb-6 text-yellow-400 drop-shadow-2xl tracking-tight bg-gradient-to-r from-yellow-300 to-yellow-500 bg-clip-text text-transparent animate-pulse">
          E-Deck ConstructIQ
        </h1>

        <p className="text-2xl md:text-3xl text-slate-200 font-bold mb-3 drop-shadow-lg">
          All-Trades Estimating & Instruction Platform
        </p>

        <p className="text-lg text-slate-300 mb-12 max-w-2xl mx-auto leading-relaxed">
          Built by S F Johnson Enterprises, LLC –{" "}
          <span className="italic text-yellow-300 font-semibold">Train. Estimate. Win Bids.</span>
        </p>

        <div className="flex flex-wrap justify-center gap-8 mb-16">
          <a
            href="/student"
            className="group bg-yellow-400 text-black text-xl px-8 py-4 rounded-2xl font-bold shadow-2xl hover:bg-yellow-300 hover:scale-105 transition-all duration-300 flex items-center gap-3 min-w-[200px] justify-center"
          >
            <GraduationCap className="h-6 w-6 group-hover:rotate-12 transition-transform duration-300" />
            Student Portal
          </a>

          <a
            href="/admin/login"
            className="group bg-transparent border-2 border-yellow-400 text-yellow-400 text-xl px-8 py-4 rounded-2xl font-bold hover:bg-yellow-400 hover:text-black hover:scale-105 transition-all duration-300 shadow-2xl flex items-center gap-3 min-w-[200px] justify-center"
          >
            <HardHat className="h-6 w-6 group-hover:rotate-12 transition-transform duration-300" />
            Instructor Login
          </a>
        </div>

        <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 shadow-2xl">
          <a
            href="https://www.sfjohnsonconsulting.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-slate-300 hover:text-yellow-300 transition-colors duration-300 flex items-center justify-center gap-2 text-lg font-medium"
          >
            Learn more at sfjohnsonconsulting.com
            <ExternalLink className="h-5 w-5" />
          </a>
        </div>
      </div>

      <footer className="absolute bottom-6 text-slate-400 text-center px-4">
        <div className="bg-black/20 backdrop-blur-sm rounded-lg px-4 py-2 border border-white/10">
          © 2025 S F Johnson Enterprises, LLC. All rights reserved.
        </div>
      </footer>
    </main>
  )
}
