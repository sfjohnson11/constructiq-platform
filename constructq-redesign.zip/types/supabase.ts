export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string
          email: string | null
          full_name: string | null
          role: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email?: string | null
          full_name?: string | null
          role?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string | null
          full_name?: string | null
          role?: string
          created_at?: string
          updated_at?: string
        }
      }
      electrical_projects: {
        Row: {
          id: string
          name: string
          description: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      electrical_plan_sets: {
        Row: {
          id: string
          project_id: string
          title: string
          file_url: string
          quiz_id: string | null
          uploaded_at: string
          created_at: string
        }
        Insert: {
          id?: string
          project_id: string
          title: string
          file_url: string
          quiz_id?: string | null
          uploaded_at?: string
          created_at?: string
        }
        Update: {
          id?: string
          project_id?: string
          title?: string
          file_url?: string
          quiz_id?: string | null
          uploaded_at?: string
          created_at?: string
        }
      }
      electrical_quizzes: {
        Row: {
          id: string
          project_id: string | null
          plan_set_id: string
          title: string
          description: string | null
          created_at: string
        }
        Insert: {
          id?: string
          project_id?: string | null
          plan_set_id: string
          title: string
          description?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          project_id?: string | null
          plan_set_id?: string
          title?: string
          description?: string | null
          created_at?: string
        }
      }
      electrical_quiz_questions: {
        Row: {
          id: string
          quiz_id: string
          question_text: string
          options: string[]
          correct_option_index: number
          created_at: string
        }
        Insert: {
          id?: string
          quiz_id: string
          question_text: string
          options: string[]
          correct_option_index: number
          created_at?: string
        }
        Update: {
          id?: string
          quiz_id?: string
          question_text?: string
          options?: string[]
          correct_option_index?: number
          created_at?: string
        }
      }
      electrical_quiz_results: {
        Row: {
          id: string
          quiz_id: string
          student_id: string
          score: number
          submitted_at: string
        }
        Insert: {
          id?: string
          quiz_id: string
          student_id: string
          score: number
          submitted_at?: string
        }
        Update: {
          id?: string
          quiz_id?: string
          student_id?: string
          score?: number
          submitted_at?: string
        }
      }
      electrical_takeoff_items: {
        Row: {
          id: string
          project_id: string
          plan_set_id: string
          item_label: string
          description: string
          location: string | null
          unit: string
          quantity: number
          material_cost: number
          labor_hours: number
          created_at: string
        }
        Insert: {
          id?: string
          project_id: string
          plan_set_id: string
          item_label: string
          description: string
          location?: string | null
          unit: string
          quantity: number
          material_cost: number
          labor_hours: number
          created_at?: string
        }
        Update: {
          id?: string
          project_id?: string
          plan_set_id?: string
          item_label?: string
          description?: string
          location?: string | null
          unit?: string
          quantity?: number
          material_cost?: number
          labor_hours?: number
          created_at?: string
        }
      }
      electrical_student_estimates: {
        Row: {
          id: string
          takeoff_item_id: string
          student_id: string
          submitted_quantity: number
          notes: string | null
          submitted_at: string
        }
        Insert: {
          id?: string
          takeoff_item_id: string
          student_id: string
          submitted_quantity: number
          notes?: string | null
          submitted_at?: string
        }
        Update: {
          id?: string
          takeoff_item_id?: string
          student_id?: string
          submitted_quantity?: number
          notes?: string | null
          submitted_at?: string
        }
      }
      study_videos: {
        Row: {
          id: string
          title: string
          description: string
          video_url: string
          quiz_id: string | null
          created_at: string
        }
        Insert: {
          id?: string
          title: string
          description: string
          video_url: string
          quiz_id?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string
          video_url?: string
          quiz_id?: string | null
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
