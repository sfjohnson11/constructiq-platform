import { createClient } from "@supabase/supabase-js"
import type { Database } from "@/types/supabase"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Missing Supabase environment variables: NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY")
}

// Create the main Supabase client
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
  },
})

// Create a client for server-side operations (if needed)
export const createServerClient = () => {
  return createClient<Database>(supabaseUrl, supabaseAnonKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
      detectSessionInUrl: false,
    },
  })
}

// Export default for backward compatibility
export default supabase

// Helper functions for common operations
export const supabaseHelpers = {
  // Auth helpers
  async getCurrentUser() {
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser()
    return { user, error }
  },

  async getUserProfile(userId: string) {
    const { data, error } = await supabase.from("user_profiles").select("*").eq("id", userId).single()
    return { data, error }
  },

  async signOut() {
    const { error } = await supabase.auth.signOut()
    return { error }
  },

  // Project helpers
  async getProjects() {
    const { data, error } = await supabase
      .from("electrical_projects")
      .select("*")
      .order("created_at", { ascending: false })
    return { data, error }
  },

  async getProjectById(id: string) {
    const { data, error } = await supabase.from("electrical_projects").select("*").eq("id", id).single()
    return { data, error }
  },

  // Plan set helpers
  async getPlanSetsByProject(projectId: string) {
    const { data, error } = await supabase
      .from("electrical_plan_sets")
      .select("*")
      .eq("project_id", projectId)
      .order("uploaded_at", { ascending: false })
    return { data, error }
  },

  // Quiz helpers
  async getQuizzesByPlanSet(planSetId: string) {
    const { data, error } = await supabase.from("electrical_quizzes").select("*").eq("plan_set_id", planSetId)
    return { data, error }
  },

  async getQuizQuestions(quizId: string) {
    const { data, error } = await supabase
      .from("electrical_quiz_questions")
      .select("*")
      .eq("quiz_id", quizId)
      .order("created_at", { ascending: true })
    return { data, error }
  },

  // Takeoff helpers
  async getTakeoffItems(planSetId: string) {
    const { data, error } = await supabase
      .from("electrical_takeoff_items")
      .select("*")
      .eq("plan_set_id", planSetId)
      .order("created_at", { ascending: true })
    return { data, error }
  },

  // Storage helpers
  async uploadFile(bucket: string, path: string, file: File) {
    const { data, error } = await supabase.storage.from(bucket).upload(path, file)
    return { data, error }
  },

  async getPublicUrl(bucket: string, path: string) {
    const { data } = supabase.storage.from(bucket).getPublicUrl(path)
    return data.publicUrl
  },

  async deleteFile(bucket: string, path: string) {
    const { data, error } = await supabase.storage.from(bucket).remove([path])
    return { data, error }
  },
}

// Type-safe table helpers
export const tables = {
  userProfiles: () => supabase.from("user_profiles"),
  electricalProjects: () => supabase.from("electrical_projects"),
  electricalPlanSets: () => supabase.from("electrical_plan_sets"),
  electricalQuizzes: () => supabase.from("electrical_quizzes"),
  electricalQuizQuestions: () => supabase.from("electrical_quiz_questions"),
  electricalQuizResults: () => supabase.from("electrical_quiz_results"),
  electricalTakeoffItems: () => supabase.from("electrical_takeoff_items"),
  electricalStudentEstimates: () => supabase.from("electrical_student_estimates"),
  studyVideos: () => supabase.from("study_videos"),
}

// Storage buckets
export const storage = {
  electrical: () => supabase.storage.from("electrical"),
  avatars: () => supabase.storage.from("avatars"),
  documents: () => supabase.storage.from("documents"),
}
