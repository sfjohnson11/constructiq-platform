import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

export interface AuthResult {
  success: boolean
  user?: any
  error?: string
  role?: string
}

export interface LoginCredentials {
  email: string
  password: string
}

export async function loginStudent({ email, password }: LoginCredentials): Promise<AuthResult> {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      return { success: false, error: error.message }
    }

    if (!data.user) {
      return { success: false, error: "Authentication failed" }
    }

    // Get user profile to check role
    const { data: profile, error: profileError } = await supabase
      .from("user_profiles")
      .select("role")
      .eq("id", data.user.id)
      .single()

    if (profileError || !profile) {
      // Create default student profile if none exists
      await supabase.from("user_profiles").insert([
        {
          id: data.user.id,
          email: data.user.email,
          role: "student",
        },
      ])
      return { success: true, user: data.user, role: "student" }
    }

    if (profile.role !== "student") {
      await supabase.auth.signOut()
      return { success: false, error: "Access denied. Student account required." }
    }

    return { success: true, user: data.user, role: profile.role }
  } catch (error) {
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function loginInstructor({ email, password }: LoginCredentials): Promise<AuthResult> {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      return { success: false, error: error.message }
    }

    if (!data.user) {
      return { success: false, error: "Authentication failed" }
    }

    // Get user profile to check role
    const { data: profile, error: profileError } = await supabase
      .from("user_profiles")
      .select("role")
      .eq("id", data.user.id)
      .single()

    if (profileError || !profile) {
      await supabase.auth.signOut()
      return { success: false, error: "Instructor profile not found. Please contact administrator." }
    }

    if (profile.role !== "instructor") {
      await supabase.auth.signOut()
      return { success: false, error: "Access denied. Instructor account required." }
    }

    return { success: true, user: data.user, role: profile.role }
  } catch (error) {
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function loginAdmin({ email, password }: LoginCredentials): Promise<AuthResult> {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      return { success: false, error: error.message }
    }

    if (!data.user) {
      return { success: false, error: "Authentication failed" }
    }

    // Get user profile to check role
    const { data: profile, error: profileError } = await supabase
      .from("user_profiles")
      .select("role")
      .eq("id", data.user.id)
      .single()

    if (profileError || !profile) {
      await supabase.auth.signOut()
      return { success: false, error: "Admin profile not found. Please contact system administrator." }
    }

    if (profile.role !== "admin") {
      await supabase.auth.signOut()
      return { success: false, error: "Access denied. Administrator privileges required." }
    }

    return { success: true, user: data.user, role: profile.role }
  } catch (error) {
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function signUpStudent({
  email,
  password,
  fullName,
}: LoginCredentials & { fullName: string }): Promise<AuthResult> {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
        },
      },
    })

    if (error) {
      return { success: false, error: error.message }
    }

    if (!data.user) {
      return { success: false, error: "Registration failed" }
    }

    // Create user profile
    const { error: profileError } = await supabase.from("user_profiles").insert([
      {
        id: data.user.id,
        email: data.user.email,
        full_name: fullName,
        role: "student",
      },
    ])

    if (profileError) {
      console.error("Profile creation error:", profileError)
      // Continue anyway as the user was created
    }

    return { success: true, user: data.user, role: "student" }
  } catch (error) {
    return { success: false, error: "An unexpected error occurred during registration" }
  }
}

export async function getCurrentUser() {
  try {
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser()

    if (error || !user) {
      return null
    }

    // Get user profile
    const { data: profile } = await supabase.from("user_profiles").select("role, full_name").eq("id", user.id).single()

    return {
      ...user,
      role: profile?.role || null,
      full_name: profile?.full_name || null,
    }
  } catch (error) {
    return null
  }
}

export async function signOut() {
  try {
    const { error } = await supabase.auth.signOut()
    if (error) {
      console.error("Sign out error:", error)
      return { success: false, error: error.message }
    }
    return { success: true }
  } catch (error) {
    return { success: false, error: "An unexpected error occurred during sign out" }
  }
}

export async function resetPassword(email: string) {
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/reset-password`,
    })

    if (error) {
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (error) {
    return { success: false, error: "An unexpected error occurred" }
  }
}

// Role-based access control helpers
export function requireRole(userRole: string | null, requiredRoles: string[]): boolean {
  if (!userRole) return false
  return requiredRoles.includes(userRole)
}

export function isStudent(userRole: string | null): boolean {
  return userRole === "student"
}

export function isInstructor(userRole: string | null): boolean {
  return userRole === "instructor"
}

export function isAdmin(userRole: string | null): boolean {
  return userRole === "admin"
}

// Auth state helpers
export function onAuthStateChange(callback: (user: any) => void) {
  return supabase.auth.onAuthStateChange(async (event, session) => {
    if (session?.user) {
      const user = await getCurrentUser()
      callback(user)
    } else {
      callback(null)
    }
  })
}
